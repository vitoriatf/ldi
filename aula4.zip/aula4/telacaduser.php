<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styleuser.css">
    <title>Document</title>
</head>
<body>
    <form action="inseriruser.php" method="POST">
         Nome:
        <input type="text" name="cxnome"/><br/>
         Email:
        <input type="e-mail" name="cxemail"/><br/>
         Senha:
        <input type="password" name="cxsenha"/><br/>
        <input type="submit" value="Gravar">
    </form>
</body>
</html>