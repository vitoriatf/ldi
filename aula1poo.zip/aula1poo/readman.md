--NOTEBOOK
Características/atributos/variável
-CPU
-GPU
-RAM

Comportamento/método/função
-ligar()
-processamento()

Estado atual 
-desligado

--CANETA
Características/atributos/variável
-cor
-marca
-tampa

Comportamento/método/função
-escrever()
-()

Estado atual 
-escrevendo



1-O que é programação orientada ao objeto?
2-O que é instanciar?
3-O que é um objeto?
4-O que é uma classe?
5-Explique sobre POO;
6-Explique sobre ->;
7-Explique sobre $this->nome;
8-Explique sobre new;
9-Explique sobre os quatro pilares da POO;
10-Qual é o time brasileiro que não tem mundial?