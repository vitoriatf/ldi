<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <?php include_once "control/pessoa.php" ?>
</head>
<body>
    <h1>Cadastro de Pessoas</h1>
    <?php 
        $cliente = new Pessoa;
        echo "Nome: ".$cliente->nome."<br>";
        echo "Idade: ".$cliente->idade=45 . "<br>";
        echo "Apelido: ".$cliente->apelido."<br>";
        echo "Telefone: ".$cliente->telefone."<br>";

    ?>
    <h1>Cadastro de Amigos</h1>
    <?php 
        $amigo = new Pessoa;
        echo "Nome: ".$amigo->nome="Manoel Gomes"."<br>";
        echo "<h1>Exemplo de função</h1>";
        $amigo->exibirdados();
    ?>
</body>
</html>