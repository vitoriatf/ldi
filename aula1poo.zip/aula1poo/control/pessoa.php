<?php
    //declaração de variável
    //colocar sempre a classe com a primeira letra em caica alta
    class Pessoa{
        //declaração de variável
        //visibilidade public = tipo pública roda em todos os arquivos
        //visibilidade private roda somente no arquivo que foi declarada
        public $nome = "Anselmo";
        public $idade;
        public $apelido = "Moacir";
        public $telefone = 12345678;
        //método tipo de função
        public function exibirdados(){
            echo "Nome:" . $this->nome = "Laiza";
        }
    }

?>