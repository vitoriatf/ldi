<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menu</title>
    <link rel="stylesheet" href="css/stylemenu.css">
</head>
<body>
    <section id="cxprincipal">
        <header id="banner">
            <h1>Site muito legal</h1>
        </header>
        <nav id="cxamigo">
            <a href="telaamigos.php">Cadastro Amigo</a> <br><br>
            <a href="telaamigos.php"><img src="img/amigos.png"></a>
        </nav>
        <nav id="cxcomercio">
            <a href="telacomercial.php">Cadastro Comércio</a> <br><br>
            <a href="telacomercial.php"><img src="img/comercial.png"></a>
        </nav>
        <nav id="cxusuario">
            <a href="telacaduser.php">Cadastro Usuário</a> <br><br>
            <a href="telacaduser.php"><img src="img/foto.png"></a>
        </nav>
        <nav id="cxconsultaamigo"></nav>
        <nav id="cxconsultacomercio"></nav>
        <nav id="cxconsultauser"></nav>
        <footer id="cxfooter">
            <p>&copy; Vitória Takeshita Ferranti - 3° INFO</p>
        </footer>
    </section>
</body>
</html>