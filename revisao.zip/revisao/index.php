<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    HOME | História | Contatos - Perfil:
    <hr>
    <h1>Cadastrar Produto</h1>
    <a href="view/produto/telacadastrar.php">Cadastrar</a>
     | 
    <a href="view/produto/telaconsultanome.php">Consultar</a>
     | Alterar | Excluir
</body>
</html>