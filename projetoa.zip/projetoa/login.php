<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <title>Login</title>
</head>
<body>
    <section id="cxprincipal">
        <figure id="cxcadeado">
            <img src="img/foto.png" alt="">
        </figure>

        <header id="cxlogin">
            <h1>Login</h1> <br>
            Email: <br>
            <input type="email" name="cxemail" class="cxemail"><br>
            Senha: <br>
            <input type="password" name="cxsenha" class="cxsenha"><br>
            <br/>
            <input type="submit" value="acessar">
        </header>
    </section>
    
</body>
</html>