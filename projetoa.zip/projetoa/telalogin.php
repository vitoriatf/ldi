<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="css/estilo.css">
    <title>Login</title>
</head>
<body>
    <section id="cxprincipal">
        <figure id="cxcadeado">
            <img src="img/user.png" class="fig1">
        </figure>
        <header id="cxlogin">
            Login: <br>
            <input type="email" name="cxemail" class="cxemail"><br>
            Senha: <br>
            <input type="password" name="cxsenha" class="cxsenha"><br>
            <input type="submit" value="Acessar">
    </section>
</body>
</html>