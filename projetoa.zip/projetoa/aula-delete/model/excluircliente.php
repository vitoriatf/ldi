<?php
    include_once "../factory/conexao.php";
    $id = $_GET["id"];
    $excluir = "delete from tbcliente where codigo = '$id'";
    $executar = mysqli_query($conn, $excluir);
    if($executar){
        echo "Cliente excluído com sucesso!";
        echo "<br>";
        echo "<a href='../view/consultacliente.php'> voltar</a>";
    }
    else{
        echo "Erro ao excluir o cliente";
    }
?>