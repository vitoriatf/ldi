<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/styleuser.css">
    <title>Document</title>
</head>
<body>
    <section>
    <form action="inseriramigos.php" method="POST">
         Amigo:
        <input type="text" name="cxamigo"/><br/>
         Email:
        <input type="e-mail" name="cxemail"/><br/>
         Telefone:
        <input type="text" name="cxtelefone"/><br/>
         Whats:
        <input type="text" name="cxwhats"/><br/>
         Data de nascimento:
        <input type="date" name="cxnascimento"/><br/>
        <input type="submit" value="Gravar">
    </form>
    <hr size="5" color="#0f0" width="320">
    <form action="consultanomeamigos.php" method="POST">
        Digite o nome completo do seu amigo:
        <input type="text" name="cxpesquisanome">
        <input type="submit" value="Buscar">
    </form>
    </section>
</body>
</html>