<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/stylemenu.css">
</head>
<body>
    <section id="cxprincipal">
        <header id="banner">
            <h1>Site muito legal</h1>
        </header>
        <nav id="cxamigo">
            <a href="telaamigos.php">Cadastro Amigo</a>
        </nav>
        <nav id="cxcomercio">
            <a href="telacomercial.php">Cadastro Comércio</a>
        </nav>
        <nav id="cxusuario">
            <a href="telacaduser.php">Cadastro Usuário</a>
        </nav>
        <nav id="cxconsultaamigo"></nav>
        <nav id="cxconsultacomercio"></nav>
        <nav id="cxconsultauser"></nav>
        <h1>sadasdasddasdas</h1>
    </section>
</body>
</html>