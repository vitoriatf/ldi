<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menu</title>
    <link rel="stylesheet" href="../css/stylemenu.css">
    <?php
        SESSION_START();
        if((!isset($_SESSION["email"])==true) &&(!isset($_SESSION["senha"])==true)){
            header("location:../index.php");
        }
        $logado = $_SESSION['email'];
    ?>
</head>
<body>
    <header class="navbar">
        <h1>Site Muito Legal</h1>
        <div class="nav-links">
            <span>Usuário: <?php echo $logado; ?></span>
            <a href="../model/sair.php">SAIR</a>
        </div>
    </header>

    <main class="content">
        <section id="cxprincipal">
            <nav id="cxamigo">
                <a href="telaamigos.php#form-cadastro">Cadastro Amigo</a> <br><br>
                <a href="telaamigos.php#form-cadastro"><img src="../img/amigos.png" alt="Amigos"></a>
            </nav>
            <nav id="cxcomercio">
                <a href="telacomercial.php#form-cadastro">Cadastro Comércio</a> <br><br>
                <a href="telacomercial.php#form-cadastro"><img src="../img/comercial.png" alt="Comercial"></a>
            </nav>
            <nav id="cxusuario">
                <a href="telacaduser.php#form-cadastro">Cadastro Usuário</a> <br><br>
                <a href="telacaduser.php#form-cadastro"><img src="../img/foto.png" alt="Usuário"></a>
            </nav>
            <nav id="cxconsultaamigo">
                <a href="telaamigos.php#form-busca">Controle de Amigos (consultar, excluir e alterar)</a>
            </nav>
            <nav id="cxconsultacomercio">
                <a href="telacomercial.php#form-busca">Controle de Comércio (consultar, excluir e alterar)</a>
            </nav>
            <nav id="cxconsultauser">
                <a href="telacaduser.php#form-busca">Controle de Usuário (consultar, excluir e alterar)</a>
            </nav>
        </section>
    </main>

    <footer class="footer">
        <p>&copy; Vitória Takeshita Ferranti - 3° INFO</p>
    </footer>
</body>
</html>