<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menu</title>
    <link rel="stylesheet" href="../css/stylemenu.css">
    <?php
        SESSION_START();
        if((!isset($_SESSION["email"])==true) &&(!isset($_SESSION["senha"])==true)){
            header("location:../index.php");
        }
        $logado = $_SESSION['email'];
    ?>
</head>
<body>
    <section id="cxprincipal">
        <header id="banner">
            <h1>Site muito legal (mudar nome e add logo)</h1>
            Usuário:
        <?php echo $logado ?> | <a href="../model/sair.php">SAIR</a> 
        </header>
        <nav id="cxamigo">
            <a href="telaamigos.php">Cadastro Amigo</a> <br><br>
            <a href="telaamigos.php"><img src="../img/amigos.png"></a>
        </nav>
        <nav id="cxcomercio">
            <a href="telacomercial.php">Cadastro Comércio</a> <br><br>
            <a href="telacomercial.php"><img src="../img/comercial.png"></a>
        </nav>
        <nav id="cxusuario">
            <a href="telacaduser.php">Cadastro Usuário</a> <br><br>
            <a href="telacaduser.php"><img src="../img/foto.png"></a>
        </nav>
        <nav id="cxconsultaamigo">
            Controle de Amigos
            <a href="">Consultar</a>
            <a href="">Excluir</a>
            <a href="">Alterar</a>
        </nav>
        <nav id="cxconsultacomercio">
            Controle de Comércio
            <a href="">Consultar</a>
            <a href="">Excluir</a>
            <a href="">Alterar</a>
        </nav>
        <nav id="cxconsultauser">
            Controle de Usuário
            <a href="">Consultar</a>
            <a href="">Excluir</a>
            <a href="">Alterar</a>
        </nav>
        <footer id="cxfooter">
            <p>&copy; Vitória Takeshita Ferranti - 3° INFO</p>
        </footer>
    </section>
</body>
</html>