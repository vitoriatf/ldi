<?php
    class CadastroGeral{
        public $nome="Anselmo";
        public $endereco;
        public $fone;
        public $tipo;
        public $idade;
        public $email;
        public $cpf;

        function geral($no, $en, $fo, $ti, $id, $em, $cp){
            echo "<h1>Dados do Professor</h1>";
            echo "Prof ". $this->nome = $no . "<br>";
            echo "Endereço ".$this->endereco = $en . "<br>";
            echo "Telefone ".$this->fone = $fo . "<br>";
            echo "Tipo ".$this->tipo = $ti . "<br>";
            echo "Idade ".$this->idade = $id . "<br>";
            echo "E-mail ".$this->email = $em . "<br>";
            echo "CPF ".$this->cpf = $cp . "<br>";

        }
    }

?>