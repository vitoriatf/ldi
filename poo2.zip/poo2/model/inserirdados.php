<?php
    include_once "../control/cadastrogeral.php";
    $cadastro = new CadastroGeral;
    $cadastro->geral($_POST['cxnome'], $_POST['cxendereco'], $_POST['cxtelefone'], $_POST['cxtipo'], $_POST['cxidade'], $_POST['cxemail'], $_POST['cxcpf']);
?>